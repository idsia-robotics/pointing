#%% Definitions. Always run this

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import itertools
import pathlib
import sys
import yaml

with open('targets.yaml') as f:
    targets = yaml.load(f.read())["targets"]
targets=[
    {"id":t["target"]["id"],
     "x":t["target"]["pose"]["x"],
     "y":t["target"]["pose"]["y"]} for t in targets]
targetorder=[t["id"] for t in targets]


#% Setup plotting
import seaborn as sns
mode_colors=[(0.3,0.5,0.7),(0.1,0.4,0.1)]
sns.palplot(mode_colors)
colormap={"joystick":mode_colors[0],"pointing":mode_colors[1]}

def setstyle(stylename):
    sns.set()
    sns.set_style(stylename, {"font.family": "serif"})
    sns.set_context("paper",font_scale=0.9)
    sns.set_palette(mode_colors)
    

def savefig(fig,fn,width_inches,height_inches):
    fig.set_size_inches(width_inches, height_inches)
    try:
        plt.tight_layout()
    except:
        pass
    fig.savefig("{}.png".format(fn),dpi=600)
    fig.savefig("{}.pdf".format(fn))
    fig.savefig("{}.svg".format(fn))
    return fig
    
IEEE_2COL = 7.16 # IEEE \textwidth in inches
IEEE_1COL = 3.5 # IEEE \columnwidth in inches

#%% Only run this cell (time consuming) to read the original data from the .bag files

import rosbag_pandas_fix
def readfrombag(fn,topic):
    import rosbag
    bag = rosbag.Bag(fn)
    ts = []
    data = []
    for topic, msg, t in bag.read_messages(topics=topic):
        ts.append(t.to_nsec())
        data.append(msg.data)
    bag.close()
    return pd.Series(index=pd.to_datetime(ts,unit="ns"),data=data)

def readRelevantTopics(fn):
    state=readfrombag(fn,"/idsia/gestures_joy/state")
    target_id=readfrombag(fn,"/idsia/gestures_joy/target_id")
    cancels=rosbag_pandas_fix.bag_to_dataframe(fn,include="/idsia/gestures_joy/cancel_last_segment").index
    bebop=rosbag_pandas_fix.bag_to_dataframe(fn,include="/optitrack/bebop").loc[:,["optitrack_bebop__pose_position_"+xyz for xyz in ("x","y","z")]].rename(columns=lambda s: s[-1:])
    return state,target_id,cancels,bebop

def drawEvents(bebop,state,t0,t1):
    fig,ax=plt.subplots(figsize=(30,10))
    ax.plot(bebop.loc[t0:t1,"z"])
    for ti,(tt,ts) in enumerate(state.loc[t0:t1].iteritems()):
        y=ti*(1.0/3)-np.floor(ti*(1.0/3))
        ax.text(tt,y,ts,rotation=90,ha="right",va="bottom")
        ax.axvline(tt,linewidth=2,color="k",alpha=0.3)
    ax.set_xlim([t0,t1])
    ax.set_xlabel("timestamp")
    ax.set_ylabel("height")
    ax.set_title(fn)

def findMoves(state,cancels,target_id):
    s = state[(state=="STATE_IDLE") | (state=="STATE_LANDING")]
    s = pd.concat((s,pd.Series(index=cancels,data="CANCEL"),target_id)).sort_index()
    
    moves = []
    numbers = ["1","2","3","4"]
    for i in range(1,len(s)-1):
        if(s.iloc[i]!="STATE_IDLE"):
            continue
        if(s.iloc[i-1] not in numbers):
            continue
        if(s.iloc[i+1]!="STATE_LANDING"):
            continue
        if((i+2 < len(s)) and (s.iloc[i+2] not in numbers)):
            continue
        #print("identified segment with target "+s.iloc[i-1])
        moves.append({
            "t0":        s.index[i],
            "t1":        s.index[i+1],
            "target1":   int(s.iloc[i-1])})
    return moves    

def readfile(fn):
    state,target_id,cancels,bebop=readRelevantTopics(fn)
    moves=findMoves(state,cancels,target_id)
    moveorder=[(1, 2), (2, 4), (4, 3), (3, 1)]
    for move,(target0,target1) in zip(moves,itertools.cycle(moveorder)):
        move["xyz"]=bebop.loc[move["t0"]:move["t1"],:]
        assert(move["target1"]==target1)
        move["target0"]=target0
    return pd.DataFrame(moves)


#  Read a specific bagfile (only for debugging)

if(False):
    fn="..."
    moves=readfile(str(fn))

# Actually read moves (takes time)

movess=[]
for fn in pathlib.Path(".").glob("*.bag"):
    print("Reading {}".format(fn))
    sys.stdout.flush()
    moves=readfile(str(fn))
    print("Read {} moves".format(len(moves)))
    moves["file"]=fn
    moves["mode"],moves["session"] = fn.stem.split("-",1)
    moves["seq"]=moves.index
    movess.append(moves)
m=pd.concat(movess,axis=0).reset_index()

# Fix user1 data [due to split session]
user1first=m.session=="user1_first_2_2017-09-08-18-22-30"
user1last=m.session=="user1_last_2017-09-08-18-37-34"
m=m.drop(user1first & (m.seq==9))
user1first=m.session=="user1_first_2_2017-09-08-18-22-30"
user1last=m.session=="user1_last_2017-09-08-18-37-34"
m.loc[user1last,"seq"]=m.loc[user1last,"seq"]+user1first.sum()
m.loc[user1first|user1last,"session"]="user1_join"

#%% Save the data from the bag files
# m.to_pickle("alldata.pickle")

#%% Load the saved data from the bags
m = pd.read_pickle("alldata.pickle")


#% Enrich data with extra information
def findState_SELECT(r):
    states=r.state[r.t0:r.t1]
    found=states[states=="STATE_SELECT"].index
    assert(len(found)==1)
    return found[0]

m["t0_select"]=m.apply(findState_SELECT,axis=1)
assert((m["t0_select"]>=m["t0"]).all())


def findState_HOLD_FOR_LANDING(r):
    states=r.state[r.t0:r.t1]
    found=states[states=="STATE_HOLD_FOR_LANDING"].index
    if(len(found)==0):
        return pd.NaT
    else:
        return found[-1]

m["t1_holdforlanding"]=m.apply(findState_HOLD_FOR_LANDING,axis=1)
assert((m.loc[m["mode"]=="pointing"]["t1_holdforlanding"].isnull()==False).all())
assert((m.loc[m["mode"]=="joystick"]["t1_holdforlanding"].isnull()==True ).all())
m.loc[m["mode"]=="joystick","t1_holdforlanding"]=m.loc[m["mode"]=="joystick","t1"]
assert((m["t1_holdforlanding"].isnull()==False).all())

def findFirstMove(r):
    xy=r.xyz[["x","y"]][r.t0_select:r.t1]
    dists=np.linalg.norm(xy.values-xy.iloc[[0]].values,axis=1)
    far=xy.loc[dists>0.2].index
    assert(len(far)>0)
    return far[0]
m["t0_firstmove"]=m.apply(findFirstMove,axis=1)
assert((m["t0_firstmove"]>=m["t0_select"]).all())
assert((m["t1_holdforlanding"]>=m["t0_firstmove"]).all())

mpoint=m.loc[m["mode"]=="pointing"]
assert((((mpoint["t1"]-mpoint["t1_holdforlanding"]).dt.total_seconds()-3.22).abs()<1).all())

#% Add information about targets
m=pd.merge(m, 
     pd.DataFrame(targets).rename(columns={"x":"target1_x","y":"target1_y"}),
     how='left', left_on="target1", right_on="id")
m=pd.merge(m, 
     pd.DataFrame(targets).rename(columns={"x":"target0_x","y":"target0_y"}),
     how='left', left_on="target0", right_on="id")

m["final_x"]=m["xyz"].apply(lambda xyz: xyz.iloc[-1,:]["x"])
m["final_y"]=m["xyz"].apply(lambda xyz: xyz.iloc[-1,:]["y"])

m["final_dist"]=np.linalg.norm(
    m.loc[:,["final_x","final_y"]].values-m.loc[:,["target1_x","target1_y"]].values,
    axis=1)

def path_length(xyz):
    return np.sum(np.linalg.norm(np.diff(xyz.loc[:,["x","y"]].values,axis=0),axis=1))
m["target01_dist"]=np.linalg.norm(m[["target1_x","target1_y"]].values-m[["target0_x","target0_y"]].values,axis=1)
m["path_length"]=m["xyz"].apply(path_length)
m["rel_path_length"]=m["path_length"].values/m["target01_dist"].values


def unit_vector(vector):
    """ Returns the unit vector of the vector.  """
    return vector / np.linalg.norm(vector,axis=1)[:,np.newaxis]

def angle_between(v1, v2):
    """ Returns the angle in radians between vectors 'v1' and 'v2'::

            >>> angle_between((1, 0, 0), (0, 1, 0))
            1.5707963267948966
            >>> angle_between((1, 0, 0), (1, 0, 0))
            0.0
            >>> angle_between((1, 0, 0), (-1, 0, 0))
            3.141592653589793
    """
    v1_u = unit_vector(v1)
    v2_u = unit_vector(v2)
    return np.arccos(np.clip(np.einsum('ij,ij->i', v1_u, v2_u), -1.0, 1.0))

m["final_dist_r"]=np.abs(
    np.linalg.norm(m.loc[:,["final_x","final_y"]].values,axis=1)-
    np.linalg.norm(m.loc[:,["target1_x","target1_y"]].values,axis=1))
m["final_dist_theta"]=angle_between(
    m.loc[:,["final_x","final_y"]].values,
    m.loc[:,["target1_x","target1_y"]].values)*\
    np.linalg.norm(m.loc[:,["target1_x","target1_y"]].values,axis=1)


#%% Statistical analysis of times

m["dur_t0_t1"]=(m["t1"]-m["t0"])/pd.Timedelta("1 second")
m["dur_t0select_t1holdforlanding"]=(m["t1"]-m["t0_select"])/pd.Timedelta("1 second")
m["dur_t0select_t1"]=(m["t1"]-m["t0_select"])/pd.Timedelta("1 second")
m["dur_t0firstmove_t1holdforlanding"]=(m["t1_holdforlanding"]-m["t0_firstmove"])/pd.Timedelta("1 second")
m["dur_t0firstmove_t1"]=(m["t1"]-m["t0_firstmove"])/pd.Timedelta("1 second")

timestats=m.groupby("mode")[["dur_t0_t1","dur_t0select_t1","dur_t0firstmove_t1","dur_t0firstmove_t1holdforlanding"]].agg(["mean","std"])
with open("timestats.table.tex", "w") as f:
    f.write(timestats.to_latex(float_format="{:0.1f}".format))
with open("timestats.table.html", "w") as f:
    f.write(timestats.to_html(float_format="{:0.1f}".format))
print(timestats)

# Choose one to make the next tests on
durfield="dur_t0firstmove_t1holdforlanding"

#%%  Analyze time vs seq
timestats_seq=m.groupby(["mode",pd.cut(m.seq, [0,4,8,12])])[durfield].mean().unstack()
with open("timestats_seq.table.tex", "w") as f:
    f.write(timestats_seq.to_latex(float_format="{:0.1f}".format))
with open("timestats_seq.table.html", "w") as f:
    f.write(timestats_seq.to_html(float_format="{:0.1f}".format))
    
print(timestats_seq)

#%% Statistical analysis of distance from target at landing
diststats=m.groupby("mode")[["final_dist","final_dist_r","final_dist_theta"]].agg(["mean","std"])

with open("diststats.table.tex", "w") as f:
    f.write(diststats.to_latex(float_format="{:0.3f}".format))
with open("diststats.table.html", "w") as f:
    f.write(diststats.to_html(float_format="{:0.3f}".format))
print(diststats)

#%% Statistical analysis of total length traveled
lengthstats=m.groupby("mode")[["path_length","rel_path_length"]].agg(["mean","std"])
with open("lengthstats.table.tex", "w") as f:
    f.write(lengthstats.to_latex(float_format="{:0.2f}".format))
with open("lengthstats.table.html", "w") as f:
    f.write(lengthstats.to_html(float_format="{:0.2f}".format))
print(lengthstats)

#%% Make all boxplots
setstyle("whitegrid")
fig,ax=plt.subplots()
sns.boxplot(data=m,
            x="mode",
            y=durfield,
            ax=ax)
ax.set(title="",
       xlabel="Mode",
       ylabel="Time [s]")
savefig(fig, "timestats", IEEE_1COL, 3)

fig,ax=plt.subplots()
sns.boxplot(data=m,
            x="mode",
            y="final_dist",
            ax=ax)
ax.set(title="",
       xlabel="Mode",
       ylabel="Landing distance from target [m]")
savefig(fig, "diststats", IEEE_1COL, 3)

fig,ax=plt.subplots()
measures=["final_dist","final_dist_r","final_dist_theta"]
sns.boxplot(data=pd.melt(m, 
                         id_vars=['mode'], 
                         value_vars=measures,
                         var_name='measure',
                         value_name='distance'),
            x="measure",
            order=measures,
            hue="mode",
            y="distance",
            ax=ax)
ax.set(title="",
       xticklabels=["total\ndistance","radial\ncomponent","tangential\ncomponent"],
       xlabel="Measure",
       ylabel="Landing distance from target [m]")
savefig(fig, "diststats_components", IEEE_1COL, 3)

fig,ax=plt.subplots()
sns.boxplot(data=m,
            x="mode",
            y="path_length",
            ax=ax)
ax.set(title="",
       xlabel="Mode",
       ylabel="Length traveled [m]")
savefig(fig, "lengthstats", IEEE_1COL, 3)

fig,ax=plt.subplots()
sns.boxplot(data=m,
            x="mode",
            y="rel_path_length",
            ax=ax)
ax.set(title="",
       xlabel="Mode",
       ylabel="Length traveled relative to\nstraight-line distance")
savefig(fig, "lengthstats_relative", IEEE_1COL, 3)

# Make length boxplots per individual move
setstyle("whitegrid")
fig,ax=plt.subplots()
movename=m["target0"].astype(str)+"to"+m["target1"].astype(str)
sns.boxplot(data=m,
            x=movename,
            order=["1to2","4to3","2to4","3to1"],
            hue="mode",
            y="path_length",
            ax=ax)
ax.set_xticklabels(["1to2\n(horiz)","4to3\n(horiz)","2to4\n(diag)","3to1\n(diag)"])
ax.set(title="",
       xlabel="Move",
       ylabel="Length traveled [m]")
savefig(fig, "lengthstats_pertarget", IEEE_1COL, 3)



#%% Analyze distance to target

def dist_to_target(xyz,t0,target_x,target_y,resample_t):
    dist=np.linalg.norm(xyz.loc[:,["x","y"]].values-np.array([[target_x,target_y]]),axis=1)
    dist_t=(xyz.index-t0)/pd.Timedelta("1s")
    return np.interp(resample_t, dist_t, dist)

t0,t1=-2,15
t=np.arange(t0-1,t1+1,0.1)

setstyle("whitegrid")
fig,axs=plt.subplots(ncols=3,sharex=True,sharey=True)
handles=dict()
for ax,mode in zip(axs,["joystick","pointing"]):
    c=colormap[mode]
    dists=[]
    for r in m[m["mode"]==mode].iterrows():
        dist=dist_to_target(
            r[1]["xyz"],
            r[1]["t0_firstmove"],  # How to define t=0?
            r[1]["target1_x"],r[1]["target1_y"],t)
        ax.plot(t,dist,color=c,alpha=0.3,linewidth=0.5)
        dists.append(dist)
    handles[mode]=axs[2].plot(t,np.mean(np.array(dists),axis=0),color=c,alpha=0.9,linewidth=2,linestyle="-")
    ax.set(title=mode,
           xlim=[t0,t1])
           
for ax in axs:
    ax.set(xlabel="time [s]")
    from matplotlib.ticker import MaxNLocator
    ax.xaxis.set_major_locator(MaxNLocator(prune='both'))
    
axs[0].set(ylabel="distance from target [m]")
axs[2].set(title="comparison of means")
axs[2].legend([h[0] for l,h in handles.iteritems()],
              [l    for l,h in handles.iteritems()],
              loc="upper right")

savefig(fig, "disttotarget", IEEE_2COL, 3)

#%% Make complete trajectory plot

considertargets=[1,2,3,4]
def makecross(x,y):
    l=0.5
    ax.plot([x-l,x+l],[y,y],color="k",linewidth=1)
    ax.plot([x,x],[y-l,y+l],color="k",linewidth=1)

setstyle("white")
fig,axs=plt.subplots(ncols=2,sharex=True,sharey=True)
for ax,mode in zip(axs,["joystick","pointing"]):
    c=colormap[mode]
    for t in targets:
        makecross(t["x"],t["y"])
    ax.plot(0,0,color="gray",marker="*",markersize=20)
    for r in m[(m["mode"]==mode) & (m["target1"].isin(considertargets))].iterrows():
        ax.plot(r[1]["xyz"]["x"],r[1]["xyz"]["y"],color=c,linewidth=0.3,alpha=0.7)
        ax.plot(r[1]["xyz"]["x"].iloc[-1],r[1]["xyz"]["y"].iloc[-1],color=c,marker=".",alpha=0.7)
        #ax.text(r[1]["xyz"]["x"].iloc[0],r[1]["xyz"]["y"].iloc[0],"b")
        #ax.text(r[1]["xyz"]["x"].iloc[-1],r[1]["xyz"]["y"].iloc[-1],"e")
    
    ax.set_aspect("equal")
    lim=2.8
    ax.set_xlim([-lim,+lim])
    ax.set_ylim([-lim,+lim])
    ax.set_title(mode)
    ax.invert_xaxis()
    ax.invert_yaxis()
savefig(fig, "trajectories-complete", IEEE_2COL, IEEE_2COL/2+0.2)

    
#%% Make trajectory plot only for move 1 to 2
sns.set()
sns.set_style("white", {"font.family": "serif"})
sns.set_context("paper",font_scale=0.9)

considertargets=[2]
def makecross(x,y):
    l=0.5
    ax.plot([x-l,x+l],[y,y],color="k",linewidth=1)
    ax.plot([x,x],[y-l,y+l],color="k",linewidth=1)

fig,ax=plt.subplots()
for t in targets:
    makecross(t["x"],t["y"])
ax.plot(0,0,color="gray",marker="*",markersize=20)
widthmap={"joystick":0.5,"pointing":1.5}
alphamap={"joystick":0.8,"pointing":0.5}
handles=dict()
for mode in ["joystick","pointing"]:
    c=colormap[mode]  
    for r in m[(m["mode"]==mode) & (m["target1"].isin(considertargets))].iterrows():
        handles[mode]=ax.plot(
                r[1]["xyz"]["x"],
                r[1]["xyz"]["y"],
                color=c,
                linewidth=widthmap[mode],
                alpha=alphamap[mode])
        ax.plot(r[1]["xyz"]["x"].iloc[-1],r[1]["xyz"]["y"].iloc[-1],color=c,marker=".",alpha=1)

ax.text(1.8,-1.2," Target 1\n (start)")
ax.text(0,0,"     Operator")     
ax.set_aspect("equal",adjustable="datalim")
lim=2.6
ax.set_xlim([-lim+0.2,+lim-0.3])
ax.set_ylim([-lim,+0.0])
ax.invert_xaxis()
ax.invert_yaxis()
ax.legend([handle[0] for label,handle in handles.iteritems()],
          [label     for label,handle in handles.iteritems()],
          loc="lower left")
ax.set(xlabel="World x",
       ylabel="World y",
       title="Trajectory comparison for move 1 to 2")
savefig(fig, "trajectories-single", IEEE_2COL, 4.5)

#%% Make trajectory animation for move 1 to 2
sns.set()
sns.set_style("white", {"font.family": "serif"})
sns.set_context("paper",font_scale=0.9)

considertargets=[2]
def makecross(x,y):
    l=0.5
    ax.plot([x-l,x+l],[y,y],color="k",linewidth=1)
    ax.plot([x,x],[y-l,y+l],color="k",linewidth=1)

fig,ax=plt.subplots()
for t in targets:
    makecross(t["x"],t["y"])
ax.plot(0,0,color="gray",marker="*",markersize=20)
widthmap={"joystick":0.5,"pointing":1.5}
alphamap={"joystick":0.4,"pointing":0.2}
handles=[]
for mode in ["joystick","pointing"]:
    c=colormap[mode]  
    for ix,r in m[(m["mode"]==mode) & (m["target1"].isin(considertargets))].iterrows():
        dfxy=r["xyz"][["x","y"]]
        dfxy=dfxy.set_index((dfxy.index-r["t0_firstmove"])/pd.Timedelta("1s"))
        handles.append(
            {"line":ax.plot(
                [0],[0],
                color=c,
                linewidth=widthmap[mode],
                alpha=alphamap[mode],zorder=5)[0],
             "dot":
                 ax.plot(0,0,color=c,marker=".",alpha=1,zorder=10)[0],
             "xy":dfxy,
             "t1_holdforlanding":(r["t1_holdforlanding"]-r["t0_firstmove"])/pd.Timedelta("1s"),
             "frames_landed":0})



def sizelanded(frameslanded):
    if(frameslanded==0):
        return 10
    else:
        return max(0,100-frameslanded*20)

ax.text(1.8,-1.2," Target 1\n (start)")
ax.text(0,0,"     Operator")     
ax.set_aspect("equal",adjustable="datalim")
lim=2.6
htext=plt.text(0.99, 0.01, 'timer', ha='right', va='bottom', 
               transform=ax.transAxes, family="monospace")
ax.set_xlim([-lim+0.2,+lim-0.3])
ax.set_ylim([-lim,+0.0])
ax.invert_xaxis()
ax.invert_yaxis()
ax.legend([handles[0]["line"], handles[-1]["line"]],
          ["joystick","pointing"],
          loc="lower left")
ax.set(xlabel="World x",
       ylabel="World y",
       title="Trajectory comparison for move 1 to 2")
       
savefig(fig, "trajectories-single-anim-master", IEEE_2COL, 4.5)
for i,t in enumerate(np.arange(0,30,0.0333)):
#for i,t in enumerate(np.arange(0,30,1)):
    for h in handles:
        h["line"].set(
            xdata = h["xy"]["x"].loc[0:t].values,
            ydata = h["xy"]["y"].loc[0:t].values)
        h["dot"].set(
            xdata = h["xy"]["x"].loc[0:t].iloc[-1],
            ydata = h["xy"]["y"].loc[0:t].iloc[-1],
            markersize = sizelanded(h["frames_landed"]))
        if(t>h["t1_holdforlanding"]):
            h["frames_landed"]=h["frames_landed"]+1
        htext.set(text="{:06.3f} seconds"
                        .format(t))
    fig.savefig("trajectories-single-anim-{:05g}.png".format(i),dpi=200)
#%%
!ffmpeg -i trajectories-single-anim-%05d.png trajectories-single-anim.mp4