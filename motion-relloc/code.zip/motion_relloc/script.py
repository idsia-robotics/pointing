#%%
import pandas as pd
import numpy as np
import transforms3d

#%%
sessions = []
files = ["data/motion_relloc_circle_2018-01-30-17-27-33.pkl",
         "data/motion_relloc_triangle_2018-01-30-17-22-35.pkl"]
for file in files:
    df = pd.read_pickle(file)
    session = (df.button.diff()==1).cumsum()
    session[df.button == 0] = None
    for s in session.dropna().unique():
        tdf = df.loc[session==s].loc[df.button != 0]
        sessions.append({
                "file":file,
                "session":s,
                "quats":tdf.loc[:,["qw","qx","qy","qz"]].values.T,
                "p":tdf.loc[:,["gt_x","gt_y","gt_z"]].values.T,
                "p_h":tdf.loc[:,["h_x","h_y","h_z"]].values.T
        })
#%%
import yaml
with open("human.yaml") as f:
    human = yaml.load(f)["human"]

# Implements the human perception model. q is the direction of the arm
def quaternion_to_line(q, model = "upperarm"):
    """ Converts input quaternion (direction of the arm) to a ray expressed as
    3D point and a 3D direction vector. Together they identify a line in space.
    Implements the human perception model.
    """
    M = transforms3d.quaternions.quat2mat(q)
    if(model == "upperarm"):
        vec = np.array([[-1, 0, 0]]).T
        tvec = np.dot(M, vec)
        center = np.array([[0,0,human["ground_to_neck"]]]).T
    elif(model == "eyefinger"):
        armlength = (human["shoulder_to_myo1"] + human["myo1_to_elbow"] + 
                     human["elbow_to_myo2"] + human["myo2_to_wrist"] +
                     human["wrist_to_finger"])
        shoulderfingervector = np.array([[-armlength, 0, 0]]).T
        shoulderfingervector = np.dot(M, shoulderfingervector)
        eyeshouldervector = np.array([[0, 0, -human["neck_to_eyes"]]]).T #
        eyefingervector = eyeshouldervector + shoulderfingervector
        tvec = eyefingervector / np.linalg.norm(eyefingervector)
        center = np.array([[0,0,human["ground_to_neck"]+human["neck_to_eyes"]]]).T # eye height
    else:
        assert(False)
    
    return center,tvec


def interpret_quaternions(quats, model = "upperarm"):
    qc,qv=[],[]
    for q in quats.T:
        c,v=quaternion_to_line(q, model)
        qc.append(c)
        qv.append(v)
    qc=np.hstack(qc)
    qv=np.hstack(qv)
    return qc,qv

# Each column of p, qc, qv represents respectively:
# - a 3D point in the frame of reference of the robot
# - a 3D point in the frame of reference of the human
# - a 3D direction in the frame of reference of the human
# qc and qv identify a line in space in the frame of reference of the human

#%%  Code to plot a session
%matplotlib qt5   
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import matplotlib.pyplot as plt

def set_axes_equal(ax):
    '''Make axes of 3D plot have equal scale so that spheres appear as spheres,
    cubes as cubes, etc..  This is one possible solution to Matplotlib's
    ax.set_aspect('equal') and ax.axis('equal') not working for 3D.

    Input
      ax: a matplotlib axis, e.g., as output from plt.gca().
    '''

    x_limits = ax.get_xlim3d()
    y_limits = ax.get_ylim3d()
    z_limits = ax.get_zlim3d()

    x_range = abs(x_limits[1] - x_limits[0])
    x_middle = np.mean(x_limits)
    y_range = abs(y_limits[1] - y_limits[0])
    y_middle = np.mean(y_limits)
    z_range = abs(z_limits[1] - z_limits[0])
    z_middle = np.mean(z_limits)

    # The plot bounding box is a sphere in the sense of the infinity
    # norm, hence I call half the max range the plot radius.
    plot_radius = 0.5*max([x_range, y_range, z_range])

    ax.set_xlim3d([x_middle - plot_radius, x_middle + plot_radius])
    ax.set_ylim3d([y_middle - plot_radius, y_middle + plot_radius])
    ax.set_zlim3d([z_middle - plot_radius, z_middle + plot_radius])

def plotSession(session, model = "upperarm"):
    quats,p,p_h = session["quats"],session["p"],session["p_h"]
    qc,qv = interpret_quaternions(quats, model)

    fig, (ax1, ax2) = plt.subplots(ncols = 2, figsize=(25,10), subplot_kw=dict(projection='3d'))
    
    for q in (quats[:,::10]).T:
        c,v=quaternion_to_line(q)
        ax1.plot(*list(zip(c.flatten(),(c+v).flatten())),color="k", alpha=0.2)
    set_axes_equal(ax1)
    ax1.set_title("Pointing rays in human frame")
    
    ax2.plot(p[0,:],p[1,:],p[2,:],color="b")
    ax2.plot(p_h[0,:],p_h[1,:],p_h[2,:],color="k")
    ax2.set_title("Robot trajectory (blue) and head trajectory (black) in robot frame")
    set_axes_equal(ax2)
    fig.tight_layout()

# plotSession(sessions[0], "eyefinger")


def plotSessionWithBothModels(session):
    quats,p,p_h = session["quats"],session["p"],session["p_h"]
    fig, ax1 = plt.subplots(figsize=(15,10), subplot_kw=dict(projection='3d'))
    for model,color in [("upperarm", "k"), ("eyefinger", "b")]:
        for q in (quats[:,::100]).T:
            c,v=quaternion_to_line(q, model)
            ax1.plot(*list(zip(c.flatten(),(c+v).flatten())),color=color, alpha=0.2)
    set_axes_equal(ax1)
    ax1.set_title("Pointing rays in human frame")
    fig.tight_layout()

plotSessionWithBothModels(sessions[0])

#%%  Definitions

def makeTransform(tx,ty,tz,rotz):
    ''' Creates a 4x4 rigid transform matrix with
    translation: tx,ty,tz
    rotation: rotz radians around z axis
    '''
    rot=transforms3d.axangles.axangle2mat([0,0,1], rotz)
    return transforms3d.affines.compose([tx,ty,tz], rot, [1,1,1])

def transformPoints(points,tf):
    ''' Input matrix of N points (one per column) 3xN
    Outputs points in the same format '''
    points_h=np.vstack((points,np.ones((1,points.shape[1]))))
    tpoints=np.matmul(tf,points_h)
    return tpoints[0:3,:]/tpoints[3,:]

def unit_vector(vector):
    """ Returns the unit vector of the vector.  """
    return vector / np.linalg.norm(vector)

def angle_between(v1, v2):
    """ Returns the angle in radians between vectors 'v1' and 'v2'::

            >>> angle_between((1, 0, 0), (0, 1, 0))
            1.5707963267948966
            >>> angle_between((1, 0, 0), (1, 0, 0))
            0.0
            >>> angle_between((1, 0, 0), (-1, 0, 0))
            3.141592653589793
    """
    v1_u = unit_vector(v1)
    v2_u = unit_vector(v2)
    return np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0))

def errorFor(p,qc,qv,tx,ty,tz,rotz):
    """ Transform points p using tx,ty,tz,rotz.
    For each transformed point tp, compute the angle between:
    - the direction joining qc and tp
    - the direction qv
    """
    tf=makeTransform(tx,ty,tz,rotz)
    tp=transformPoints(p,tf)
    return [angle_between(v1, v2) for v1,v2 in zip(qv.T,(tp-qc).T)]

import scipy.optimize

def optimize(p,qc,qv,x0):
    """ Given points in robot frame (p) and rays in human frame (qc,qv), find
    transformation parameters from human frame to robot frame that minimize the
    residual, using starting x0 as the initial solution """

    def f(x):
        return np.mean(errorFor(p,qc,qv,*x))

    return scipy.optimize.minimize(f,x0)

#%% Example on one specific session: optimization
 
if(False):
    session = sessions[-1]
    quats,p,p_h = session["quats"],session["p"],session["p_h"]
    model = "upperarm"
    #model = "eyefinger"
    qc,qv = interpret_quaternions(quats, model)
    
    res = optimize(p,qc,qv,[0,0,0,0]) # uses all data
    # res = optimize(p[:,::10],qc[:,::10],qv[:,::10],[0,0,0,0]) # downsample data
    # res = optimize(p[:,600::],qc[:,600::],qv[:,600::],[0,0,0,0]) # use only second half
    # res = optimize(p[:,:5*30],qc[:,:5*30],qv[:,:5*30],[0,0,0,0]) # use only first 5 seconds
    
    
    print("Average angular error (residual) in deg: {:.2f}".format(np.rad2deg(res.fun)))
    print("Recovered transform (tx,ty,tz,rotz): {:.2f},{:.2f},{:.2f},{:.2f}".format(
            res.x[0],
            res.x[1],
            res.x[2],
            np.rad2deg(res.x[3])))


#%% Example on one specific session: drawing

def ClosestPointOnLine(qc, qv, p, minimum=0.5):
    cp = p-qc
    qv_unit = qv / np.linalg.norm(qv)
    distance = np.dot(cp,qv_unit)
    in_front = distance > 0
    distance = max(distance, minimum)
    return (qc + distance * qv_unit), in_front

def drawFrame(q,tpoint,tpoint_h,ax):
    qc, qv = quaternion_to_line(q)
    qc, qv = qc.flatten(), qv.flatten()
    qp, in_front = ClosestPointOnLine(qc, qv, tpoint)
    color = "k" if in_front else "r"
    return {
        "line": ax.plot(*list(zip(qc,qp)), color = color, alpha=0.2),
        "closestpoint": ax.plot([qp[0]],[qp[1]],[qp[2]], color = color, marker = "o", alpha=1, mfc='none'),
        "robot": ax.plot([tpoint[0]],[tpoint[1]],[tpoint[2]], "ko", alpha=1),
        "human": ax.plot([tpoint_h[0]],[tpoint_h[1]],[tpoint_h[2]], "bo", alpha=1)
    }

if(False):
    fig, ax = plt.subplots(figsize=(15,10), subplot_kw=dict(projection='3d'))
        
    tf=makeTransform(*res.x)
    tp=transformPoints(p,tf)
    tp_h=transformPoints(p_h,tf)
    
    frames = []
    for i in range(0,len(quats.T),5):
        frames.append(drawFrame(quats.T[i], tp.T[i], tp_h.T[i],ax))
    
    ax.set_aspect("equal")
    set_axes_equal(ax)
    plt.show()

#%% Example on one specific session: drawing
import time
import pathlib

if(False):
    animdir = pathlib.Path("anim")
    animdir.mkdir(exist_ok=True)
    for i in range(len(frames)):
        for h in frames[i].values():
            h[0].set_visible(False)
    for i in range(len(frames)):
        for j in range(i-10):
            for h in frames[j].values():
                h[0].set_visible(False)
        for h in frames[i].values():
            h[0].set_visible(True)
        plt.draw()
        plt.pause(1/10)
        fig.savefig(str(animdir/("anim_{:05d}.png".format(i))))


#%% Functions for experiments
import tqdm  
import itertools
def simulate_vo(p,sigma):
    p_vo = p + np.cumsum(np.random.randn(*p.shape)*sigma, axis=1)
    err_vo = np.linalg.norm(p-p_vo,axis=0)
    return p_vo,np.mean(err_vo),np.max(err_vo)

# Define an error metric
def compute_error(x,p_h):
    """ Compute the position error of the estimated transformation, by checking
        where the head position would be according to such transformation, and
        comparing that to the measured position of the head p_h
        
        BTW: an alternative implementation may be simpler
    """
    
    
    tf_hr = makeTransform(*x)  # From human frame to robot frame
    tf_rh = np.linalg.inv(tf_hr)  # From robot frame to human frame
    head_h = np.array([0,0,1.83,1])[:,np.newaxis] # head position as homogeneous vector in human frame
    head_r = np.dot(tf_rh,head_h) # head position as homogeneous vector in robot frame according to estimated tf
    head_r = head_r[:3]/head_r[3] # cartesian
    head_gt = np.mean(p_h,axis=1,keepdims=True) # head position as cartesian vector in robot frame according to optitrack
    err = head_r - head_gt
    return err

# Options for initialization
x0_0 = [0,0,0,0]
def experiment(session, samples, init, model, replica, vo_sigma):
    
    # Read in session data
    quats,p,p_h = session["quats"],session["p"],session["p_h"]
    qc,qv = interpret_quaternions(quats, model)

    # take a subset of samples
    np.random.seed(seed=replica)
    startix = np.random.randint(0,p.shape[1]-samples)
    ix = slice(startix,startix+samples)
    extent = np.max(np.linalg.norm((p[:,ix].T[np.newaxis,:,:] - p[:,ix].T[:,np.newaxis,:]),axis=2))
    traj_length = np.sum(np.linalg.norm(np.diff(p[:,ix].T, axis=0),axis=1))
    p_vo, err_vo_mean, err_vo_max = simulate_vo(p[:,ix], vo_sigma)
    
    # Define initialization
    x0 = {"x0_0": x0_0,
          "random": np.random.uniform(-100,100,size=(4,))}[init]

    opt = optimize(p_vo,qc[:,ix],qv[:,ix],x0)
    x = opt.x
    residual = opt.fun
    
    err = compute_error(x,p_h[:,ix])
    
    # Save results
    tres=dict()
    for i in ('session', 'samples', 'init', 'model', 'replica', 'vo_sigma',
              'ix', 'x', 'residual', 'err', 'traj_length', 'traj_extent', 'err_vo_mean', 'err_vo_max'):
        tres[i] = locals()[i]
    return tres


#%% Robustness to initialization
# x0_close = optimize(p,qc,qv,[0,0,0,0]).x
inits = ["random"]
# models = ["upperarm","eyefinger"]
models = ["upperarm"]
vo_sigmas = [0,     # Perfect VO
             0.001, # Decent VO
             0.005, # Bad VO
             0.015  # Terrible VO
             ]

res = []
for samples,replicas in tqdm.tqdm(list(zip(
       (np.array([0.5, 1,  2,  3,  5, 10, 20]) * 30).astype(int),
                 [10]))):
#       (np.array([0.5, 1,  2,  3,  5, 10, 20 ]) * 30).astype(int),
#                  [15, 15, 15, 10, 10, 5,  5]))):
#                  [5, 5, 5, 3, 3, 1, 1]))):
    for replica in range(replicas):
        for session,init,model,vo_sigma in itertools.product(sessions,inits,models,vo_sigmas):
            res.append(experiment(session, samples, init, model, replica, vo_sigma))
            
res = pd.DataFrame(res)


#%% Run large scale experiments
# x0_close = optimize(p,qc,qv,[0,0,0,0]).x
inits = ["x0_0"]
# models = ["upperarm","eyefinger"]
models = ["upperarm","eyefinger"]
vo_sigmas = [0,     # Perfect VO
             0.001, # Good VO
             0.005, # Bad VO
             0.015  # Terrible VO
             ]

res = []
for samples,replicas in tqdm.tqdm(list(zip(
       (np.array([0.5, 1,  2,  3,  5, 10, 20]) * 30).astype(int),
                 [20, 20, 20, 20, 20, 10,  5]))):
#       (np.array([0.5, 1,  2,  3,  5, 10, 20 ]) * 30).astype(int),
#                  [15, 15, 15, 10, 10, 5,  5]))):
#                  [5, 5, 5, 3, 3, 1, 1]))):
    for replica in range(replicas):
        for session,init,model,vo_sigma in itertools.product(sessions,inits,models,vo_sigmas):
            res.append(experiment(session, samples, init, model, replica, vo_sigma))
            
res = pd.DataFrame(res)

#fig = plt.figure(figsize=(10,10))
#ax = fig.add_subplot(111, projection='3d')
#ax.plot(p[0,:],p[1,:],p[2,:])
#ax.plot(p_vo[0,:],p_vo[1,:],p_vo[2,:])

#%% Save
res.to_pickle("saved.pickle")

#%% Process experiment results and make plots
%matplotlib inline
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_context("paper")
res["samples_s"] = res["samples"]/30
res["errxy"] = res["err"].apply(lambda x: np.linalg.norm(x[:2]))
res["errz"] = res["err"].apply(lambda x: x[2,0])
res["sessionid"] = res["session"].apply(lambda x: "{}-s{}".format(x["file"].split("_")[2],int(x["session"])))

#figheight = 1
#figwidth = 7.0625
g = sns.factorplot(data=res[(res["vo_sigma"] != 0) & (res["model"] == "upperarm")], x="samples_s", y="errxy", 
                   row="vo_sigma",
                   #hue="vo_sigma",
                   col="sessionid", kind="box",
                   color = "gray",
                   #palette=sns.color_palette("viridis",3), 
                   fliersize=2,
                   size = 2.4, aspect = 1.2,
                   )
(g.set_axis_labels("Trajectory duration [s]", "xy error for operator head [m]")
  .set_titles("Session {col_name}, vo noise $\sigma = $ {row_name}")
  .set(ylim = [0,2]))
#l = ax.legend()
#l.set_title('Whatever you want')
plt.gcf().savefig("results.png",dpi=400)

#%% Make a table for visual odometry errors
table = (res.groupby(["vo_sigma","samples_s"])["traj_length","extent","err_vo_mean","err_vo_max"]
    .mean()
    .unstack(level=0))

table.insert(0,("tr_length","-"),table.loc[:,("traj_length",0)])
table.insert(1,("tr_extent","-"),table.loc[:,("extent",0)])
table = table.drop(columns = ["traj_length","extent"])
print(table.round(2).to_latex())

#%% Multirobot
import random

def multirobot_experiment(session, session_other, samples, init, model, replica, vo_sigma):
    
    # Read in session data
    quats,p,p_h = session["quats"],session["p"],session["p_h"]
    qc,qv = interpret_quaternions(quats, model)

    # Read in other session data
    p_other = session_other["p"]

    # take a subset of samples for session
    np.random.seed(seed=replica)
    startix = np.random.randint(0,p.shape[1]-samples)
    ix = slice(startix,startix+samples)
    
    # take a subset of samples for other session
    startix = np.random.randint(0,p_other.shape[1]-samples)
    ix_other = slice(startix,startix+samples)
    
    
    traj_extent = np.max(np.linalg.norm((p[:,ix].T[np.newaxis,:,:] - p[:,ix].T[:,np.newaxis,:]),axis=2))
    traj_length = np.sum(np.linalg.norm(np.diff(p[:,ix].T, axis=0),axis=1))
    p_vo, err_vo_mean, err_vo_max = simulate_vo(p[:,ix], vo_sigma)
    
    p_other_vo, _, _ = simulate_vo(p_other[:,ix_other], vo_sigma)
    
    # Define initialization
    x0 = {"x0_0": x0_0,
          "random": np.random.uniform(-100,100,size=(4,))}[init]

    opt = optimize(p_vo,qc[:,ix],qv[:,ix],x0)
    x = opt.x
    residual = opt.fun
    
    err = compute_error(x,p_h[:,ix])
    
    opt_other = optimize(p_other_vo,qc[:,ix],qv[:,ix],x0)
    x_other = opt_other.x
    residual_other = opt_other.fun
    
    err = compute_error(x,p_h[:,ix])
    
    # Save results
    tres=dict()
    for i in ('session', 'session_other', 'samples', 'init', 'model', 'replica', 'vo_sigma',
              'ix', 'x', 'residual', 'residual_other', 'err', 'traj_length', 'traj_extent', 'err_vo_mean', 'err_vo_max'):
        tres[i] = locals()[i]
    return tres

inits = ["x0_0"]
models = ["upperarm"]
vo_sigmas = [#0,     # Perfect VO
             0.001, # Good VO
             0.005, # Bad VO
             0.015  # Terrible VO
             ]

circlesessions = [s for s in sessions if "circle" in s["file"]]
trianglesessions = [s for s in sessions if "triangle" in s["file"]]

res = []
for samples,replicas in tqdm.tqdm(list(zip(
       (np.array([0.5, 1,  2,  3,  5, 10, 20]) * 30).astype(int),
                 [20, 20, 20, 20, 20, 20, 20]))):
#       (np.array([0.5, 1,  2,  3,  5, 10, 20 ]) * 30).astype(int),
#                  [15, 15, 15, 10, 10, 5,  5]))):
#                  [5, 5, 5, 3, 3, 1, 1]))):
    for replica in range(replicas):
        for session,init,model,vo_sigma in itertools.product(sessions,inits,models,vo_sigmas):
            if(session in circlesessions):
                session_other = random.choice(trianglesessions)
            else:
                session_other = random.choice(circlesessions)
            res.append(multirobot_experiment(session, session_other, samples, init, model, replica, vo_sigma))
            
res = pd.DataFrame(res)

#%% Save
res.to_pickle("saved_multirobot.pickle")


#%% Process experiment results and make plots
%matplotlib inline
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_context("paper")
res["samples_s"] = res["samples"]/30
res["success"] = res["residual"]<res["residual_other"]
res["sessionid"] = res["session"].apply(lambda x: "{}-s{}".format(x["file"].split("_")[2],int(x["session"])))
res["sessionid_other"] = res["session_other"].apply(lambda x: "{}-s{}".format(x["file"].split("_")[2],int(x["session"])))

fig,ax = plt.subplots(figsize=(5,3))
sns.barplot(x="samples_s", y="success", hue="vo_sigma", palette="viridis", ci=90, data=res)
ax.set(ylim=(0.5,1.01),
       ylabel="success rate",
       xlabel="Trajectory duration [s]")
fig.tight_layout()
plt.legend(loc='bottom right')
for t in ax.get_legend().texts:
    t.set_text("$\sigma = {}$".format(t.get_text()))
fig.savefig("results-multirobot.png",dpi=400)

#%%  Still debugging this plot, ignore from here below

#res["origin"] = res["x"].apply(lambda x:
#    transformPoints(np.mean(p_h,axis=1,keepdims=True),makeTransform(*x)))
#
res["err_x"]=res["err"].apply(lambda x: x[0,0])
res["err_y"]=res["err"].apply(lambda x: x[1,0])

# Crosshair
chlx=np.array([[-1,1],[ 0,0] ]).T*1.0
chly=np.array([[ 0,0],[-1,1],]).T*1.0

groups = res.groupby(["model","sessionid"])
fig,axs=plt.subplots(
            figsize = (20,10),
            nrows=len(res["model"].unique()),
            ncols=len(res["sessionid"].unique()))
for ((model,sessionid),data),ax in zip(groups,axs.flatten()):
    ax.plot(chlx,chly,linewidth=0.5,color="k")
    ax.set(title=str(model),
           xlim=[-1,1],
           ylim=[-1,1],
           aspect=1)
    ax.plot(data["err_x"],data["err_y"],"o",alpha=0.5)
